# Module implementation report (batch 1)

Legend: Test = "compiled/in-game tested". Nothing here has been compiled or run yet.

| Module | Status | Features | Known limitations | Test |
|---|---|---|---|---|
| Auto Totem | Implemented | HUD: offhand totem state, total count, empty-offhand warning, position, reset | Display only; never moves items | Untested |
| Auto Inv Totem | Implemented | HUD list of totem slots (hotbar/inventory), max entries, position, reset | Display only | Untested |
| Mace Swap | Implemented | Key selects first hotbar mace, swap-back, missing notice | Hotbar only; no inventory pull | Untested |
| Spear Swap | Implemented | Same as Mace Swap for any *_spear item | Hotbar only | Untested |
| All other modules | Not started | - | - | - |

Framework: toggle, per-module settings screen, defaults, reset button, JSON persistence
(config/trainingkit.json), tooltips, per-module crash isolation (a throwing module is disabled and its error shown).
