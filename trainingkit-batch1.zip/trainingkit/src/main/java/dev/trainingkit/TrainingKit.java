package dev.trainingkit;

import dev.trainingkit.core.Config;
import dev.trainingkit.core.ModuleManager;
import dev.trainingkit.gui.ModuleListScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TrainingKit implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("trainingkit");
    public static final KeyBinding.Category KEY_CATEGORY =
            KeyBinding.Category.create(Identifier.of("trainingkit", "main"));
    private static KeyBinding openKey;

    /** Registers an unbound-by-default (or given default) key under the TrainingKit category. */
    public static KeyBinding key(String id, int glfwKey) {
        return KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.trainingkit." + id, InputUtil.Type.KEYSYM, glfwKey, KEY_CATEGORY));
    }

    @Override
    public void onInitializeClient() {
        openKey = key("open", GLFW.GLFW_KEY_RIGHT_SHIFT);
        ModuleManager.init();
        Config.load();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.wasPressed()) mc.setScreen(new ModuleListScreen(null));
            ModuleManager.tick(mc);
        });
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> ModuleManager.hud(ctx));
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Config.save());
    }
}
