package dev.trainingkit.core;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class BoolSetting extends Setting<Boolean> {
    public BoolSetting(String name, String tooltip, boolean def) { super(name, tooltip, def); }
    @Override protected String display() { return value ? "ON" : "OFF"; }
    @Override public void cycle() { value = !value; changed(); }
    @Override public JsonElement toJson() { return new JsonPrimitive(value); }
    @Override public void fromJson(JsonElement e) { value = e.getAsBoolean(); }
}
