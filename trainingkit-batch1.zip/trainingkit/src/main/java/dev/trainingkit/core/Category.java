package dev.trainingkit.core;

public enum Category {
    COMBAT("Combat"), MISC("Misc"), DONUT("Donut"), BASE("Base"), RENDER("Render"), CLIENT("Client");
    public final String label;
    Category(String label) { this.label = label; }
}
