package dev.trainingkit.core;

import com.google.gson.*;
import dev.trainingkit.TrainingKit;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** JSON persistence: config/trainingkit.json. Corrupt entries fall back to defaults. */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static boolean loading;
    private Config() { }

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("trainingkit.json"); }

    public static void load() {
        loading = true;
        try {
            Path p = path();
            if (!Files.exists(p)) return;
            JsonObject root = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
            for (Module m : ModuleManager.all()) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                JsonObject s = o.has("settings") ? o.getAsJsonObject("settings") : new JsonObject();
                for (Setting<?> st : m.settings()) {
                    try { if (s.has(st.name)) st.fromJson(s.get(st.name)); }
                    catch (Exception e) { TrainingKit.LOG.warn("Bad value for {}.{}, using default", m.name, st.name); }
                }
                if (o.has("enabled") && o.get("enabled").getAsBoolean()) m.restoreEnabled(true);
            }
        } catch (Exception e) {
            TrainingKit.LOG.warn("Could not read config, using defaults", e);
        } finally { loading = false; }
    }

    public static void save() {
        if (loading) return;
        try {
            JsonObject root = new JsonObject();
            for (Module m : ModuleManager.all()) {
                JsonObject o = new JsonObject(), s = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                for (Setting<?> st : m.settings()) s.add(st.name, st.toJson());
                o.add("settings", s);
                root.add(m.name, o);
            }
            Files.writeString(path(), GSON.toJson(root));
        } catch (Exception e) {
            TrainingKit.LOG.warn("Could not save config", e);
        }
    }
}
