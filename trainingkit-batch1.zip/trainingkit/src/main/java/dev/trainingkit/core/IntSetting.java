package dev.trainingkit.core;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class IntSetting extends Setting<Integer> {
    private final int min, max, step;
    public IntSetting(String name, String tooltip, int def, int min, int max, int step) {
        super(name, tooltip, def); this.min = min; this.max = max; this.step = step;
    }
    @Override protected String display() { return Integer.toString(value); }
    @Override public void cycle() { value = value + step > max ? min : value + step; changed(); }
    @Override public JsonElement toJson() { return new JsonPrimitive(value); }
    @Override public void fromJson(JsonElement e) { value = Math.max(min, Math.min(max, e.getAsInt())); }
}
