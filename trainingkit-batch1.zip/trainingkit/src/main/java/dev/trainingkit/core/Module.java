package dev.trainingkit.core;

import dev.trainingkit.TrainingKit;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Base class: activation, settings, error isolation, reset. */
public abstract class Module {
    public final String name, description;
    public final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    private String lastError;

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }
    public List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }
    public boolean isEnabled() { return enabled; }
    public String lastError() { return lastError; }

    /** Return a human-readable reason if this module cannot run right now, else null. */
    protected String unsupportedReason(MinecraftClient mc) { return null; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        if (on) {
            String reason = unsupportedReason(MinecraftClient.getInstance());
            if (reason != null) { lastError = reason; return; }
            lastError = null;
        }
        enabled = on;
        try { if (on) onEnable(); else onDisable(); } catch (Throwable t) { fail(t); }
        Config.save();
    }

    /** Used by Config.load: restores state without compatibility gating (no world exists yet). */
    void restoreEnabled(boolean on) { enabled = on; if (on) try { onEnable(); } catch (Throwable t) { fail(t); } }

    public void resetToDefaults() {
        for (Setting<?> s : settings) s.reset();
        Config.save();
    }

    final void safeTick(MinecraftClient mc) {
        try {
            if (!enabled) { idle(mc); return; }
            String r = unsupportedReason(mc);
            if (r != null) { lastError = r; enabled = false; onDisable(); return; }
            tick(mc);
        } catch (Throwable t) { fail(t); }
    }

    final void safeHud(DrawContext ctx, MinecraftClient mc) {
        if (!enabled) return;
        try { renderHud(ctx, mc); } catch (Throwable t) { fail(t); }
    }

    private void fail(Throwable t) {
        TrainingKit.LOG.error("Module {} crashed and was disabled", name, t);
        lastError = t.getClass().getSimpleName() + ": " + t.getMessage();
        enabled = false;
        try { onDisable(); } catch (Throwable ignored) { }
        Config.save();
    }

    protected void onEnable() { }
    protected void onDisable() { }
    protected void tick(MinecraftClient mc) { }
    /** Called each tick while disabled (e.g. to drain key presses). */
    protected void idle(MinecraftClient mc) { }
    protected void renderHud(DrawContext ctx, MinecraftClient mc) { }
}
