package dev.trainingkit.core;

import dev.trainingkit.modules.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private ModuleManager() { }

    public static void init() {
        MODULES.add(new AutoTotem());
        MODULES.add(new AutoInvTotem());
        MODULES.add(new MaceSwap());
        MODULES.add(new SpearSwap());
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> byCategory(Category c) {
        return MODULES.stream().filter(m -> m.category == c).toList();
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        for (Module m : MODULES) m.safeTick(mc);
    }

    public static void hud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        for (Module m : MODULES) m.safeHud(ctx, mc);
    }
}
