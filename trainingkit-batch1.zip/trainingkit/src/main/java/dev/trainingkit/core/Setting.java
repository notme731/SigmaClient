package dev.trainingkit.core;

import com.google.gson.JsonElement;

/** A persisted, GUI-editable value. Every setting has a default and a reset. */
public abstract class Setting<T> {
    public final String name, tooltip;
    protected final T def;
    protected T value;

    protected Setting(String name, String tooltip, T def) {
        this.name = name; this.tooltip = tooltip; this.def = def; this.value = def;
    }
    public T get() { return value; }
    public void reset() { value = def; }
    public String label() { return name + ": " + display(); }
    protected abstract String display();
    /** Advance to the next value (button click). */
    public abstract void cycle();
    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement e);
    protected void changed() { Config.save(); }
}
