package dev.trainingkit.gui;

import dev.trainingkit.core.Category;
import dev.trainingkit.core.Module;
import dev.trainingkit.core.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public class ModuleListScreen extends Screen {
    private static final int PER_PAGE = 8;
    private static Category cat = Category.COMBAT;
    private static int page = 0;
    private final Screen parent;

    public ModuleListScreen(Screen parent) { super(Text.literal("TrainingKit")); this.parent = parent; }

    @Override protected void init() {
        Category[] cs = Category.values();
        int bw = 62, sx = width / 2 - cs.length * bw / 2;
        for (int i = 0; i < cs.length; i++) {
            Category c = cs[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(c == cat ? "[" + c.label + "]" : c.label),
                    b -> { cat = c; page = 0; clearAndInit(); }).dimensions(sx + i * bw, 10, bw - 2, 20).build());
        }
        List<Module> ms = ModuleManager.byCategory(cat);
        int pages = Math.max(1, (ms.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.min(page, pages - 1);
        for (int r = 0; r < PER_PAGE; r++) {
            int idx = page * PER_PAGE + r;
            if (idx >= ms.size()) break;
            Module m = ms.get(idx);
            int y = 40 + r * 24;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(m.name + ": " + (m.isEnabled() ? "ON" : "OFF")),
                    b -> { m.toggle(); clearAndInit(); })
                    .dimensions(width / 2 - 110, y, 170, 20).tooltip(Tooltip.of(Text.literal(m.description))).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Settings"),
                    b -> client.setScreen(new ModuleSettingsScreen(this, m)))
                    .dimensions(width / 2 + 64, y, 50, 20).build());
        }
        int by = height - 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> { page = Math.max(0, page - 1); clearAndInit(); })
                .dimensions(width / 2 - 110, by, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> { page = Math.min(pages - 1, page + 1); clearAndInit(); })
                .dimensions(width / 2 - 76, by, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(width / 2 + 14, by, 100, 20).build());
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        if (ModuleManager.byCategory(cat).isEmpty())
            ctx.drawTextWithShadow(textRenderer, "No modules implemented in this category yet.", width / 2 - 110, 50, 0xFFAAAAAA);
    }

    @Override public void close() { client.setScreen(parent); }
}
