package dev.trainingkit.gui;

import dev.trainingkit.core.Module;
import dev.trainingkit.core.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ModuleSettingsScreen extends Screen {
    private final Screen parent;
    private final Module module;

    public ModuleSettingsScreen(Screen parent, Module module) {
        super(Text.literal(module.name)); this.parent = parent; this.module = module;
    }

    @Override protected void init() {
        int y = 56, x = width / 2 - 100;
        addDrawableChild(ButtonWidget.builder(Text.literal("Enabled: " + (module.isEnabled() ? "ON" : "OFF")),
                b -> { module.toggle(); clearAndInit(); }).dimensions(x, 32, 200, 20)
                .tooltip(Tooltip.of(Text.literal(module.description))).build());
        for (Setting<?> s : module.settings()) {
            addDrawableChild(ButtonWidget.builder(Text.literal(s.label()), b -> { s.cycle(); clearAndInit(); })
                    .dimensions(x, y, 200, 20).tooltip(Tooltip.of(Text.literal(s.tooltip))).build());
            y += 24;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset to defaults"),
                b -> { module.resetToDefaults(); clearAndInit(); }).dimensions(x, y + 8, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(x, y + 32, 200, 20).build());
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, module.name, width / 2, 14, 0xFFFFFFFF);
        if (module.lastError() != null)
            ctx.drawCenteredTextWithShadow(textRenderer, module.lastError(), width / 2, height - 14, 0xFFFF5555);
    }

    @Override public void close() { client.setScreen(parent); }
}
