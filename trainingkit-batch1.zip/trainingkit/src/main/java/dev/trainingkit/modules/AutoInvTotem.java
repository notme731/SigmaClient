package dev.trainingkit.modules;

import dev.trainingkit.core.Category;
import dev.trainingkit.core.IntSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Informational only: lists where totems are in your inventory. Never moves items. */
public class AutoInvTotem extends InfoModule {
    private final IntSetting maxLines = add(new IntSetting("Max entries",
            "Maximum number of totem locations to list.", 6, 1, 12, 1));

    public AutoInvTotem() {
        super("Auto Inv Totem", "Lists the locations of Totems of Undying in your hotbar and inventory.",
                Category.COMBAT, 34);
    }

    @Override protected List<String> lines(MinecraftClient mc) {
        List<String> out = new ArrayList<>();
        PlayerInventory inv = mc.player.getInventory();
        int found = 0;
        for (int i = 0; i < 36 && found < maxLines.get(); i++) {
            if (!inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            out.add(i < 9 ? "Totem: hotbar slot " + (i + 1) : "Totem: inventory slot " + (i - 8));
            found++;
        }
        if (found == 0) out.add("No totems in inventory");
        return out;
    }
}
