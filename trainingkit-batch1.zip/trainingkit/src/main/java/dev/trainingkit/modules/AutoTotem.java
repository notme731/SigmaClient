package dev.trainingkit.modules;

import dev.trainingkit.core.BoolSetting;
import dev.trainingkit.core.Category;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Informational only: shows offhand totem state and how many totems you carry. Never moves items. */
public class AutoTotem extends InfoModule {
    private final BoolSetting warn = add(new BoolSetting("Warn when offhand empty",
            "Shows a warning line if no Totem of Undying is in your offhand.", true));

    public AutoTotem() {
        super("Auto Totem", "Displays totem availability: whether one is in your offhand and how many you carry.",
                Category.COMBAT, 4);
    }

    @Override protected List<String> lines(MinecraftClient mc) {
        boolean off = mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
        int total = off ? 1 : 0;
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) total++;
        List<String> out = new ArrayList<>();
        out.add("Totems: " + total + " | Offhand: " + (off ? "yes" : "no"));
        if (warn.get() && !off) out.add("! No totem in offhand");
        return out;
    }
}
