package dev.trainingkit.modules;

import dev.trainingkit.core.Category;
import dev.trainingkit.core.IntSetting;
import dev.trainingkit.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/** HUD text overlay module. Lines are computed once per tick and only drawn per frame. */
abstract class InfoModule extends Module {
    private final IntSetting x, y;
    private List<String> cache = List.of();

    InfoModule(String name, String desc, Category cat, int defY) {
        super(name, desc, cat);
        x = add(new IntSetting("HUD X", "Horizontal position of the overlay in pixels.", 4, 0, 1000, 20));
        y = add(new IntSetting("HUD Y", "Vertical position of the overlay in pixels.", defY, 0, 600, 20));
    }

    protected abstract List<String> lines(MinecraftClient mc);

    @Override protected void tick(MinecraftClient mc) { cache = lines(mc); }

    @Override protected void renderHud(DrawContext ctx, MinecraftClient mc) {
        int yy = y.get();
        for (String l : cache) { ctx.drawTextWithShadow(mc.textRenderer, l, x.get(), yy, 0xFFFFFFFF); yy += 10; }
    }
}
