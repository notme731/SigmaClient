package dev.trainingkit.modules;

import dev.trainingkit.TrainingKit;
import dev.trainingkit.core.BoolSetting;
import dev.trainingkit.core.Category;
import dev.trainingkit.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.function.Predicate;

/** Hotkey that selects the first matching hotbar item using the normal hotbar-selection mechanic. */
abstract class ItemSwapModule extends Module {
    private final KeyBinding key;
    private final Predicate<ItemStack> match;
    private final String itemName;
    private final BoolSetting swapBack = add(new BoolSetting("Swap back",
            "Pressing the key again while holding the item returns to your previous hotbar slot.", true));
    private final BoolSetting notify = add(new BoolSetting("Notify if missing",
            "Shows an action-bar message when no matching item is in your hotbar.", true));
    private int previous = -1;

    ItemSwapModule(String name, String keyId, String itemName, Predicate<ItemStack> match) {
        super(name, "Adds a key (set in Controls) that selects the " + itemName + " in your hotbar.", Category.COMBAT);
        this.itemName = itemName; this.match = match;
        this.key = TrainingKit.key(keyId, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override protected void idle(MinecraftClient mc) { while (key.wasPressed()) { } }

    @Override protected void tick(MinecraftClient mc) {
        while (key.wasPressed()) {
            var inv = mc.player.getInventory();
            int cur = inv.getSelectedSlot();
            if (match.test(inv.getStack(cur))) {
                if (swapBack.get() && previous >= 0 && previous != cur) inv.setSelectedSlot(previous);
                continue;
            }
            int found = -1;
            for (int i = 0; i < 9; i++) if (match.test(inv.getStack(i))) { found = i; break; }
            if (found < 0) {
                if (notify.get()) mc.player.sendMessage(Text.literal("No " + itemName + " in hotbar"), true);
                continue;
            }
            previous = cur;
            inv.setSelectedSlot(found);
        }
    }

    static boolean idEndsWith(ItemStack s, String suffix) {
        return !s.isEmpty() && Registries.ITEM.getId(s.getItem()).getPath().endsWith(suffix);
    }
}
