package dev.trainingkit.modules;

public class MaceSwap extends ItemSwapModule {
    public MaceSwap() { super("Mace Swap", "mace_swap", "mace", s -> idEndsWith(s, "mace")); }
}
