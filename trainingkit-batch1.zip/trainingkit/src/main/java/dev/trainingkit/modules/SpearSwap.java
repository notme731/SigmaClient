package dev.trainingkit.modules;

public class SpearSwap extends ItemSwapModule {
    public SpearSwap() { super("Spear Swap", "spear_swap", "spear", s -> idEndsWith(s, "_spear")); }
}
